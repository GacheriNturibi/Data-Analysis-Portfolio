# Predicting-Malaria-Prevalence-in-Kenya
This is a project that entailed using Machine Learning and Geostatistics to predict malaria prevalence in Kenya, based on climatic, environmental and socio-economic factors.
